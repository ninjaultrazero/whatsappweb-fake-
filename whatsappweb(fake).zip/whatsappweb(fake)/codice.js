function inviaMessaggio() {
    let messaggio = document.getElementById("chat-input").value;
  
    if (messaggio.trim() !== "") {
      let nuovoMessaggioLi = document.createElement("li");
      nuovoMessaggioLi.classList.add("nav-item");
  
      let nuovoMessaggioDiv = document.createElement("div");
      nuovoMessaggioDiv.classList.add("messaggio_destra");
  
      // Ottenere l'orario corrente
      let data = new Date();
      let ora = data.getHours();
      let minuti = data.getMinutes();
      let orario = ora + ":" + (minuti < 10 ? "0" + minuti : minuti);
  
      // Creare un nuovo elemento div per il testo del messaggio
      let testoMessaggioDiv = document.createElement("div");
      testoMessaggioDiv.innerText = messaggio;
  
      // Creare un nuovo elemento div per l'orario
      let orarioDiv = document.createElement("div");
      orarioDiv.classList.add("orario");
      orarioDiv.innerText = orario;
  
      // Aggiunta del testo del messaggio all'elemento div del messaggio
      nuovoMessaggioDiv.appendChild(testoMessaggioDiv);
  
      // Aggiunta dell'orario all'elemento div del messaggio
      nuovoMessaggioDiv.appendChild(orarioDiv);
  
      // Aggiunta dell'elemento div del messaggio all'elemento li
      nuovoMessaggioLi.appendChild(nuovoMessaggioDiv);
  
      // Aggiunta dell'elemento li alla lista ul
      let listaMessaggi = document.querySelector(".nav.flex-column");
      listaMessaggi.appendChild(nuovoMessaggioLi);
  
      // Pulizia dell'input
      document.getElementById("chat-input").value = "";
  
      // Scrolla verso il basso per visualizzare il nuovo messaggio
      listaMessaggi.scrollTop = listaMessaggi.scrollHeight;
    }
  }
  
  function risposta(){
  
   listamessaggirandom=new Array("si","no","qualche altra volta","forse","probabilmente","ma anche no","forza napoli");
  
    num = Math.round(Math.random() * 6);

    let nuovoMessaggioLui = document.createElement("li");
      nuovoMessaggioLui.classList.add("nav-item");
  
      let nuovoMessaggioDivo = document.createElement("div");
      nuovoMessaggioDivo.classList.add("messaggio_sinistra");
  
      // Ottenere l'orario corrente
      let data = new Date();
      let ora = data.getHours();
      let minuti = data.getMinutes()+1;
      let orario = ora + ":" + (minuti < 10 ? "0" + minuti : minuti);
  
      // Creare un nuovo elemento div per il testo del messaggio
      let testoMessaggioDivo = document.createElement("div");
      testoMessaggioDivo.innerText = listamessaggirandom[num];
      // Creare un nuovo elemento div per l'orario
      let orarioDiv = document.createElement("div");
      orarioDiv.classList.add("orario");
      orarioDiv.innerText = orario;
  
      // Aggiunta del testo del messaggio all'elemento div del messaggio
      nuovoMessaggioDivo.appendChild(testoMessaggioDivo);
  
      // Aggiunta dell'orario all'elemento div del messaggio
      nuovoMessaggioDivo.appendChild(orarioDiv);
  
      // Aggiunta dell'elemento div del messaggio all'elemento li
      nuovoMessaggioLui.appendChild(nuovoMessaggioDivo);
  
      // Aggiunta dell'elemento li alla lista ul
      let listaMessaggi = document.querySelector(".nav.flex-column");
      listaMessaggi.appendChild(nuovoMessaggioLui); 
  
  
      let elementoOrario = document.getElementById('chattestovecchio');
  
  if (elementoOrario) {
    let orarioPrefissato = listamessaggirandom[num];
    elementoOrario.textContent = orarioPrefissato;
  }
    }
  
  
  /*************************************************************************************************************************************************
    *****************************************************************************************************************************************************************************************
    ****************************************************************************************************************************************/ 
    function cambiaTesto() {
      // Ottieni il riferimento all'elemento con l'id 'zanoorario'
      let elementoOrario = document.getElementById('zanoorario');
      let data = new Date();
      let ora = data.getHours();
      let minuti = data.getMinutes()+1;
      let orario = ora + ":" + (minuti < 10 ? "0" + minuti : minuti);
      // Modifica il testo dell'elemento dopo l'invio del messaggio
      if (elementoOrario) {
          let orarioPrefissato = orario;
          elementoOrario.textContent = orarioPrefissato;
      }
  } 
    /************************************************************************************************************************************************
    ************************************************************************************************************************************************/ 
// Creazione dei bottoni
/*const elementList = [
const elementButton = document.getElementById('elementButton');
const elementContainer = document.getElementById('elementContainer');

// Array di emoji che vuoi mostrare
{ element: 'Nuovo Gruppo', path: './Matrone_Pasquale.html' },
{ element: 'Nuova Comumunity', path: './Matrone_Pasquale.html' }, 
{ element: 'Messaggi Importanti', path: './Matrone_Pasquale.html' },
{ element: 'Seleziona chat', path: './Matrone_Pasquale.html' },
{ element: 'impostazioni', path: 'settings.html' }, 
{ element: 'impostazioni', path: 'https://www.google.com' },
];

// Mostra o nascondi il container delle emoji
elementButton.addEventListener('click', () => {
  elementContainer.style.display = elementContainer.style.display === 'none' ? 'block' : 'none';

  // Aggiungi le emoji al container come elementi cliccabili
  if (elementContainer.style.display === 'block') {
    elementContainer.innerHTML = '';
    elementList.forEach(elementObj => {
      const elementElement = document.createElement('span');
      elementElement.textContent = elementObj.element;
      elementElement.classList.add('dotMenuItem'); // Add a class for styling
      elementContainer.appendChild(elementElement);

      const breakElement = document.createElement('br');
      elementContainer.appendChild(breakElement);

      // Aggiungi un gestore di eventi di clic
      elementElement.addEventListener('click', () => {
        // Cambia la posizione della finestra del browser
        window.location.href = elementObj.path;
      });
    });
  }
});*/
/**************************************************************************************************************************************************
    *****************************************************************************************************************************************************************************************
    ***************************************************************************************************************************************/ 
  
 
 
 
 
 
/*
Andrea(170--251) e Caizzo(1--169): css 
De Gennaro(163--221) e Longoboardi(1--162): HTML 
Matrone(47--113) e Marcarini(1--46): JAVASCRIPT
*/